#include <iostream>
#include <string>
#include <stdexcept>
#include <windows.h>
#include "Console.h"
#include "RandomNumber.h"
#include "Creature.h"
#include "Food.h"
#include "Board.h"
#include "Input.h"
#include <vector>
#include <algorithm>
#include "Statistics.h"

using namespace std;

int main()
{
	do
	{
		Console console(70, 70);
		console.setColour(console.COLOUR::BLACK, console.COLOUR::WHITE);
	
		Input read;
		read.readAll();

		Board board(read.getNumberOfCreature(),read.getNumberOfFood(),console);
		
		console.clear();

		board.generateCreatures(read.getNumberOfCreature());
	
		while (board.getCreaturesSize() > 0)
		{
			board.newBoard(read.getNumberOfFood(), console);

			console.clear();
		}
		
		board.localStats.printAllStats(console);
	
		console.~Console();
		board.~Board();
		read.~Input();

	}while (true);
	return 0;
}
