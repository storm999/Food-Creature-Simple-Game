#include "Board.h"


Board::Board(int numberOfCreature, int numberOfFood, Console console)
{
	console.setConsoleSize(30, 31);
	console.setColour(console.COLOUR::BLACK, console.COLOUR::WHITE);
	creatures.reserve(numberOfCreature);
	foods.reserve(numberOfFood);
	random.initialiseSeed();
}

Board::~Board()
{
}

void Board::newBoard(int numberOfFoods, Console console)
{
	printCreatures(console);
	generateFoods(numberOfFoods, console);
	//findNearestFood();
	//eat();
	localStats.incRoundNumber();
}

int Board::getCreaturesSize()
{
	return creatures.size();
}

void Board::generateCreatures(int numberOfCreature)
{
	for (int i = 0; i < numberOfCreature; i++)		//Generates Creatures
	{
		creatures.push_back(Creature(random.random(0, 29), random.random(0, 29), random.random(0, 20), i));
	}
}

void Board::printCreatures(Console console)
{
	for (int i = 0; i < creatures.size(); i++)		//Prints Creatures
	{
		console.gotoXY(creatures[i].getX(), creatures[i].getY());
		cout << creatures[i].getHitpoint();
	}
	console.gotoXY(29, 29);
	getchar();
}

void Board::generateFoods(int numberOfFood, Console console)
{
	int tempDied=0;
	for (int i = 0; i < numberOfFood; i++)		//Generating foods
	{
		foods.push_back(Food(random.random(0, 29), random.random(0, 29), i));
		console.gotoXY(foods[i].getX(), foods[i].getY());
		cout << foods[i].getFoodPattern();

		for (int j = 0; j < creatures.size(); j++)		//Kills creatures when food drop on them
		{
			if (locationCheck(j, i))
			{	
				killCreature(j);
				tempDied++;
			}
		}
	}
	localStats.setCreaturesDiedbyFoodDrop(tempDied);
	foods.clear();
	getchar();
}

void Board::killCreature(int j)
{
	creatures[j].~Creature();
	creatures.erase(creatures.begin() + j);
}

bool Board::locationCheck(int j, int i)
{
	if (creatures[j].getX() == foods[i].getX() && creatures[j].getY() == foods[i].getY())
	{
		return true;
	}
	else
		return false;
}

int Board::calculateDistance(int j, int i)
{
	int x = foods[j].getX() - creatures[i].getX();
	int y = foods[j].getY() - creatures[i].getY();
	int distance = sqrt(x*x + y*y);
	return distance;
}


/*
void Board::eat()
{
for (int i = 0; i < creatures.size(); i++)
	{
		for (int j = 0; j < foods.size(); j++)				//calculates distance of all creatures to all foods in matrix
		{
	
		Food f = creatures[i].getNearestFood();
			if (f != NULL)
			{

			}
		}
	}
}
*/

int Board::findNearestFood()
{
	int nearestFoodID = -1;
	int minDistance = 100;
	int distance;

	for (int i = 0; i<creatures.size(); i++)
	{
		for (int j = 0; j<foods.size(); j++)
		{
			distance = calculateDistance(i,j);

			if (distance < minDistance && distance <= creatures[i].getLimitDistance())
			{
				minDistance = distance;
				creatures[i].setNearestFoodID(foods[j].getId());
			}
		}
	}
	return nearestFoodID;
}