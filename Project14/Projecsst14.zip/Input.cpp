#include "Input.h"
#include <iostream>

Input::Input()
{
}

Input::~Input()
{
}

void Input::readAll()
{
	readNumberOfFood();
	readNumberOfCreatures();
	readEatDistance();
}

void Input::readNumberOfFood()
{
	std::cout << "Enter number of food: between 0 and 500:";
	std::cin >> numberOfFood;
	while (numberOfFood > 500 || numberOfFood < 0)
	{
		std::cout << "Invalid input please enter between 0 and 500";
		std::cin >> numberOfFood;
	}
}

void Input::readNumberOfCreatures()
{
	std::cout << "Enter number of creatures between 0 and 500:";
	std::cin >> numberOfCreature;
	while (numberOfCreature > 500 || numberOfCreature < 0)
	{
		std::cout << "Invalid input please enter between 0 and 500";
		std::cin >> numberOfCreature;
	}
}

void Input::readEatDistance()
{
	std::cout << "Enter max eat distance between 0 and 10:";
	std::cin >> eatDistance;
	while (eatDistance > 10 || eatDistance < 0)
	{
		std::cout << "Invalid input please enter between 0 and 10";
		std::cin >> eatDistance;
	}
}

int Input::getNumberOfCreature()
{
	return numberOfCreature;
}

int Input::getNumberOfFood()
{
	return numberOfFood;
}

int Input::getEatDistance()
{
	return eatDistance;
}