#pragma once

class Input
{
private:
	int numberOfFood;
	int numberOfCreature;
	int eatDistance;
public:
	Input();
	~Input();
	void readNumberOfFood();
	void readNumberOfCreatures();
	void readEatDistance();
	int getNumberOfCreature();
	int getNumberOfFood();
	int getEatDistance();
	void readAll();
};

