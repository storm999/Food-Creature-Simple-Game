#include "Statistics.h"
#include <iostream>

Statistics::Statistics()
{
	roundNumber = 0;
	creaturesDiedbyFoodDrop = 0;
	howManyFoodsEaten = 0;
}

Statistics::~Statistics()
{
}

void Statistics::printAllStats(Console console)
{
	console.setConsoleSize(70, 70);
	console.setColour(console.COLOUR::BLUE, console.COLOUR::WHITE);
	std::cout << "Statistics of Game" << std::endl << std::endl;
	std::cout << "Total round number: " << getRoundNumber() << std::endl;
	std::cout << "Total number of creatures that killed by food drop: " << getCreaturesDiedbyFoodDrop() << std::endl;
	std::cout << "Total number of eaten foods by creatures: " << getHowManyFoodsEaten() << std::endl << std::endl;
	std::cout << "Press 'enter' key to restart game" << std::endl;
	getchar();
	console.clear();
}

int Statistics::getRoundNumber()
{
	return roundNumber;
}

void Statistics::incRoundNumber()
{
	roundNumber++;
}

int Statistics::getCreaturesDiedbyFoodDrop()
{
	return creaturesDiedbyFoodDrop;
}

void Statistics::setCreaturesDiedbyFoodDrop(int inCreaturesDiedbyFoodDrop)
{
	creaturesDiedbyFoodDrop += inCreaturesDiedbyFoodDrop;
}

int Statistics::getHowManyFoodsEaten()
{
	return howManyFoodsEaten;
}

void Statistics::setHowManyFoodsEaten(int inHowManyFoodsEaten)
{
	howManyFoodsEaten += howManyFoodsEaten;
}