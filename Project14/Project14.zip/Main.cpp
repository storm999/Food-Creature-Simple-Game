#include <iostream>
#include <string>
#include <stdexcept>
#include <windows.h>
#include "Console.h"
#include "RandomNumber.h"
#include "Creature.h"
#include "Food.h"
#include "Board.h"
#include "Input.h"
#include <vector>
#include <algorithm>
#include "Statistics.h"

using namespace std;

int main()
{
	do
	{
		Console console(70, 70);
		console.setColour(console.COLOUR::BLACK, console.COLOUR::WHITE);
	
		Input read;
		read.readAll();

		Statistics stats;

		Board board(read.getNumberOfCreature(),read.getNumberOfFood(),console);
		
		console.clear();

		board.generateCreatures(read.getNumberOfCreature());
	
		while (board.getCreaturesSize() != 0)
		{
			board.newBoard(read.getNumberOfFood(), stats, console);
			
			/*
			for (int i = 0; i < foodsForFight.size(); i++)			//If distance of 2 creatures to same food are equal to each other then creatures fight and strongest one eats food
			{
				bool eaten = false;
				for (int j = 0; j < foodsForFight[i].size() - 1; j++)
				{
					if (creaturesForFight[i][j].getAttack() < creaturesForFight[i][j + 1].getAttack())
					{
						for (int m = 0; m < creatures.size(); m++)
						{
							if (creaturesForFight[i][j].getId() == creatures[m].getId())
							{
								creatures[m].~Creature();
							}
							else if (creaturesForFight[i][j + 1].getId() == creatures[m].getId())
							{

								console.gotoXY(creatures[m].getX(), creatures[m].getY());
								console.setColour(console.COLOUR::PURPLE, console.COLOUR::LIGHT_AQUA);
								cout << creatures[i].getHitpoint();
								console.setColour(console.COLOUR::BLACK, console.COLOUR::WHITE);
								if (eaten == false)
								{
									if (creaturesForFight[i][j + 1].getHitpoint() < 7)
									{
										creaturesForFight[i][j + 1].setHitpoint(creaturesForFight[i][j + 1].getHitpoint() + 4);
									}
									else
									{
										creaturesForFight[i][j + 1].setHitpoint(10);
									}
									eaten = true;
								}
							}
						}
					}
					else if (creaturesForFight[i][j].getAttack() > creaturesForFight[i][j + 1].getAttack())
					{
						for (int m = 0; m < creatures.size(); m++)
						{
							if (creaturesForFight[i][j + 1].getId() == creatures[m].getId())
							{
								creatures[m].~Creature();
							}
							else if (creaturesForFight[i][j].getId() == creatures[m].getId())
							{
								console.gotoXY(creatures[m].getX(), creatures[m].getY());
								console.setColour(console.COLOUR::PURPLE, console.COLOUR::LIGHT_AQUA);
								cout << creatures[i].getHitpoint();
								console.setColour(console.COLOUR::BLACK, console.COLOUR::WHITE);
								if (eaten == false)
								{
									if (creaturesForFight[i][j].getHitpoint() < 7)
									{
										creaturesForFight[i][j].setHitpoint(creaturesForFight[i][j + 1].getHitpoint() + 4);
									}
									else
									{
										creaturesForFight[i][j].setHitpoint(10);
									}
									eaten = true;
								}
							}
						}
					}
					eaten = false;
				}
			}
			*/
			
			console.clear();
		}
		
		stats.printAllStats(console);
	
		console.~Console();
		board.~Board();
		read.~Input();
		stats.~Statistics();
	}while (true);
	return 0;
}
