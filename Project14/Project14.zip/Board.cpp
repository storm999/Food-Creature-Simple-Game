#include "Board.h"


Board::Board(int numberOfCreature, int numberOfFood, Console console)
{
	console.setConsoleSize(30, 31);
	console.setColour(console.COLOUR::BLACK, console.COLOUR::WHITE);
	creatures.reserve(numberOfCreature);
	foods.reserve(numberOfFood);
	random.initialiseSeed();
}

Board::~Board()
{
}

void Board::newBoard(int numberOfFoods,Statistics stats, Console console)
{
	printCreatures(console);
	generateFoods(numberOfFoods, stats, console);
	//findNearestFood();
	//eat();
	stats.incRoundNumber();
}

int Board::getCreaturesSize()
{
	return creatures.size();
}

void Board::generateCreatures(int numberOfCreature)
{
	for (int i = 0; i < numberOfCreature; i++)	//Generates Creatures
	{
		creatures.push_back(Creature(random.random(0, 29), random.random(0, 29), random.random(0, 20), i));
	}
}

void Board::printCreatures(Console console)
{
	for (int i = 0; i < creatures.size(); i++)	//Prints Creatures
	{
		console.gotoXY(creatures[i].getX(), creatures[i].getY());
		cout << creatures[i].getHitpoint();
	}
	console.gotoXY(29, 29);
	getchar();
}

void Board::generateFoods(int numberOfFood, Statistics stats, Console console)
{
	int tempDied=0;
	for (int i = 0; i < numberOfFood; i++)	//Generating foods
	{
		foods.push_back(Food(random.random(0, 29), random.random(0, 29), i));
		console.gotoXY(foods[i].getX(), foods[i].getY());
		cout << foods[i].getFoodPattern();

		for (int j = 0; j < creatures.size(); j++)	//Kills creatures when food drop on them
		{
			if (creatures[j].getX() == foods[i].getX() && creatures[j].getY() == foods[i].getY())
			{	
				creatures[j].~Creature();
				creatures.erase(creatures.begin() + j);
				tempDied++;
				stats.setCreaturesDiedbyFoodDrop(tempDied);
			}
		}
	}
	foods.clear();
	getchar();
}

int Board::calculateDistance(vector<Food> foods, int j, vector<Creature> creatures, int i)
{
	int x = foods[j].getX() - creatures[i].getX();
	int y = foods[j].getY() - creatures[i].getY();
	int distance = sqrt(x*x + y*y);
	return distance;
}

/*void Board::destructConsole()
{
console.~Console();;
}*/
/*
void Board::eat()
{
for (int i = 0; i < creatures.size(); i++)
{
for (int j = 0; j < foods.size(); j++)				//calculates distance of all creatures to all foods in matrix
{
Food f = creatures[i].getNearestFood();
if (f != NULL)
{

}

}
}
}

int Board::findNearestFood()
{

}*/