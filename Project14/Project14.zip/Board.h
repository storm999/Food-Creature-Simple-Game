#pragma once
#include <vector>
#include <iostream>
#include <string>
#include <stdexcept>
#include <windows.h>
#include "Console.h"
#include "RandomNumber.h"
#include "Creature.h"
#include "Food.h"
#include <vector>
#include <algorithm>
#include "Input.h"
#include "Statistics.h"

class Board
{
private:
	vector<vector<int>> board;
	vector<Creature> creatures;
	vector<Food> foods;
	RandomNumber random;
public:
	Board(int, int, Console);
	~Board();
	void generateFoods(int,Statistics, Console);
	void generateCreatures(int);
	void printCreatures(Console);
	void newBoard(int,Statistics, Console);
	int getCreaturesSize();
	void eat();
	int calculateDistance(vector<Food>, int, vector<Creature>, int);
	int findNearestFood();
	void destructConsole();
};

