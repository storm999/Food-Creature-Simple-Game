#pragma once
#include <iostream>
#include <string>
#include <stdexcept>
#include <windows.h>
using namespace std;

class Food
{
private:
	int X;
	int Y;
	int id;
	int foodAmount;
	char F;
public:
	Food() = default;
	Food(int, int, int);
	~Food();
	int getX();
	int getY();
	void setLocation(int, int);
	char getFoodPattern();
	void setFoodAmount(int);
	int getFoodAmount();
	int getId();
};
