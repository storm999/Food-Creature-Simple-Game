#include "Creature.h"


Creature::Creature(int inX, int inY, int inAttack, int inId)
{
	X = inX;
	Y = inY;
	id = inId;
	attack = inAttack;
	hitpoint = 5;
}

Creature::~Creature()
{
}

int Creature::getId()
{
	return id;
}

int Creature::getX()
{
	return X;
}

int Creature::getY()
{
	return Y;
}

void Creature::setHitpoint(int inHitpoint)
{
	hitpoint = inHitpoint;
}

int Creature::getHitpoint()
{
	return hitpoint;
}

void Creature::setAttack(int inAttack)
{
	hitpoint = inAttack;
}

int Creature::getAttack()
{
	return attack;
}

Food Creature::getNearestFood()
{
	return nearestFood;
}

int Creature::getNearestFoodID()
{
	return nearestFoodID;
}

void Creature::setNearestFoodID(int id)
{
	nearestFoodID = id;
}

int Creature::getLimitDistance()
{
	return limitDistance;
}

