#pragma once
#include <iostream>
#include <string>
#include <stdexcept>
#include <windows.h>
#include "Food.h"

using namespace std;

class Creature
{
private:
	int id;
	int X;
	int Y;
	int hitpoint;
	int attack;
	int nearestFoodID;
	int limitDistance;
	Food nearestFood;
public:
	Creature(int, int, int, int);
	~Creature();
	int getId();
	void setHitpoint(int);
	int getHitpoint();
	void setAttack(int);
	int getAttack();
	int getX();
	int getY();
	int getNearestFoodID();
	void setNearestFoodID(int id);
	int getLimitDistance();
	Food getNearestFood();
};
