#include "Food.h"

Food::Food(int inX, int inY, int inId)
{
	X = inX;
	Y = inY;
	id = inId;
	F = '#';
}

Food::~Food()
{
}

void Food::setLocation(int inX, int inY)
{
	X = inX;
	Y = inY;
}

int Food::getX()
{
	return X;
}

int Food::getY()
{
	return Y;
}

char Food::getFoodPattern()
{
	return F;
}

void Food::setFoodAmount(int inFoodAmount)
{
	foodAmount = inFoodAmount;
}

int Food::getFoodAmount()
{
	return foodAmount;
}

int Food::getId()
{
	return id;
}