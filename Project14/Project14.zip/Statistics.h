#pragma once
#include "Console.h"
class Statistics
{
public:
	int roundNumber=0;
	int creaturesDiedbyFoodDrop=0;
	int howManyFoodsEaten=0;

	Statistics();
	~Statistics();
	void incRoundNumber();
	int getRoundNumber();
	void setCreaturesDiedbyFoodDrop(int);
	int getCreaturesDiedbyFoodDrop();
	void setHowManyFoodsEaten(int);
	int getHowManyFoodsEaten();
	void printAllStats(Console);
};

